#!/bin/sh
python bot.py
